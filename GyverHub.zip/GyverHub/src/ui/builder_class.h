#pragma once
#include <Arduino.h>

namespace gh {
class Builder;
}