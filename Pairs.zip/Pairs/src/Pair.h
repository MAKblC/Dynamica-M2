#pragma once
#include <Arduino.h>
#include <StringUtils.h>

class Pair : public su::Text {
   public:
    su::Text key;
};