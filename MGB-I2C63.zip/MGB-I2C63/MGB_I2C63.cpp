#include "MGB_I2C63.h"
#include <Wire.h>

MGB_I2C63::MGB_I2C63(bool scheme1) {
  scheme = scheme1;
}

bool MGB_I2C63::setBusChannel(uint8_t i2c_channel)  // смена I2C порта
{
  if (i2c_channel >= 0x08) {
    return false;
  } else {
    Wire.beginTransmission(0x70);
	if(scheme){
	 Wire.write(i2c_channel | 0x08);  // для микросхемы PCA9547
    }
	else{
	 Wire.write(0x01 << i2c_channel);  // Для микросхемы PW548A
	}
    Wire.endTransmission();
    return true;
  }
}