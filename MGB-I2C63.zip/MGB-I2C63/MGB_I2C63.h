#include <Wire.h>

class MGB_I2C63 {
 public:
  MGB_I2C63(bool scheme);
  bool setBusChannel(uint8_t i2c_channel);
  
 private:
  bool scheme;
};


